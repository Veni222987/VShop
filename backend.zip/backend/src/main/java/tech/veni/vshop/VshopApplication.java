package tech.veni.vshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VshopApplication {
	public static void main(String[] args) {
		SpringApplication.run(VshopApplication.class, args);
	}
}
