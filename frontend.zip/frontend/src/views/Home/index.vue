<script setup>

import HomeBanner from './components/HomeBanner.vue'
import HomeNew from './components/HomeNew.vue'

</script>

<template>
  <div class="container">
    <!-- <HomeCategory /> -->
    <HomeBanner />
  </div>
  <HomeNew />
  <!-- <HomeHot /> -->
  <!-- <HomeProduct /> -->

</template>